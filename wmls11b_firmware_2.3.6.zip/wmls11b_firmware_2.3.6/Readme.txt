Downloaded from http://tech.groups.yahoo.com/group/wmls11b
Just flash the firmware using the linksys util via wired ethernet, not wirelessly.
Need help?  Head there and we will be more than happy to help you!

-DJ Hewi